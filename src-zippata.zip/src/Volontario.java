public class Volontario extends Utente {
    
    public Volontario(String username, String password, boolean primoAccesso) {
        super(username, password, primoAccesso);
    }

    public Volontario(String username, String password) {
        super(username, password);
    }

    //aggiunta metodi per il volontario
}