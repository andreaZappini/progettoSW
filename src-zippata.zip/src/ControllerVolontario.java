public class ControllerVolontario {
    
private static final String AZIONI_VOLONTARIO = ""; /*"\n----------------------------------------------------------------------------------------------"
			+ "\nBenvenuto Volontario! Scegli una delle seguenti alternative: \n\n" +
            "1. Visualizzare tutti i tipi di visita a cui sei associato\n" +
            "2. Esprimere le disponibilità in termini di date\n" +
            "3. Logout\n" +
            "4. Chiudere l'applicazione\n" + 
            "------------------------------------------------------------------------------------------------\n";*/
}
